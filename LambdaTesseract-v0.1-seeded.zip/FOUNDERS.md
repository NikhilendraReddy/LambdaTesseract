# Founders & Maintainers

- **Founder & Original Proposer**: **NIKHIL REDDY**
- Project stewards: (to be listed as the community forms)

> This file records provenance for accreditation and archival purposes.
