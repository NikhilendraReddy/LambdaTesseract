# Governance

- **Founder**: **NIKHIL REDDY**
- Model: BDFL → evolves to core team via LTP (proposal) process.
- Decisions: Open RFCs in `rfcs/`, accepted by consensus + founder tie-break.
- Releases: Time-based minors, spec freezes for 1.0+.
