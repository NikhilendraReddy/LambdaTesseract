# Name & Trademark

"LambdaTesseract" is a project name for a programming language.
The name attribution is to **NIKHIL REDDY** as the original proposer.
Any actual trademark registration must be filed in the relevant jurisdictions.
