#!/usr/bin/env python3
# Very small formatter stub: trims trailing spaces and ensures newline at eof
import sys, pathlib

def fmt_file(path: pathlib.Path):
    src = path.read_text(encoding="utf-8")
    lines = [line.rstrip() for line in src.splitlines()]
    text = "\n".join(lines) + "\n"
    path.write_text(text, encoding="utf-8")

def main():
    for arg in sys.argv[1:]:
        p = pathlib.Path(arg)
        if p.is_file():
            fmt_file(p)

if __name__ == "__main__":
    main()
