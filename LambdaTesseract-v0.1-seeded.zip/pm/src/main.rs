use argh::FromArgs;

#[derive(FromArgs)]
/// LambdaTesseract package manager
struct Args {
    #[argh(subcommand)]
    cmd: Option<Cmd>,
}

#[derive(FromArgs)]
#[argh(subcommand)]
enum Cmd {
    Init(Init),
    Add(Add),
}
#[derive(FromArgs)]
#[argh(subcommand, name = "init")]
struct Init {}
#[derive(FromArgs)]
#[argh(subcommand, name = "add")]
struct Add {
    #[argh(positional)]
    pkg: String,
}

fn main() -> anyhow::Result<()> {
    let args: Args = argh::from_env();
    match args.cmd {
        Some(Cmd::Init(_)) => println!("Initialized ltpm project."),
        Some(Cmd::Add(a)) => println!("Added package: {}", a.pkg),
        None => println!("ltpm (placeholder). try: ltpm init | ltpm add foo"),
    }
    Ok(())
}
