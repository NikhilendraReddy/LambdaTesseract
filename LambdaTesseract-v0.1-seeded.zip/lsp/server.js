// Minimal LSP server placeholder
console.log("LT LSP server (placeholder)");
