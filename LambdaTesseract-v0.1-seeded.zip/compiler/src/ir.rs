#[derive(Clone, Debug)]
pub struct Module {
    pub name: String,
    pub items: Vec<Item>,
}

#[derive(Clone, Debug)]
pub enum Item {
    Func(Func),
}

#[derive(Clone, Debug)]
pub struct Func {
    pub name: String,
    pub body: Vec<Op>,
}

#[derive(Clone, Debug)]
pub enum Op {
    ConstI64(i64),
    Add,
    Call(String),
    Ret,
}
