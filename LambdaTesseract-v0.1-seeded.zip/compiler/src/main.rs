use argh::FromArgs;

#[derive(FromArgs)]
/// LambdaTesseract compiler
struct Args {
    /// input file
    #[argh(positional)]
    input: Option<String>,

    /// target (wasm/native)
    #[argh(option, default = "String::from(\"wasm\")")]
    target: String,

    /// build with incremental cache
    #[argh(switch)]
    incremental: bool,
}

fn main() -> anyhow::Result<()> {
    let args: Args = argh::from_env();
    println!("ltc: compiling {:?} -> target={} incremental={}", args.input, args.target, args.incremental);
    // TODO: parse -> HIR -> MIR -> codegen
    Ok(())
}
