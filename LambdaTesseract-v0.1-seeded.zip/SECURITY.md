# Security Policy

- Report vulnerabilities via private email: security@example.org
- Do not open public issues for unresolved vulnerabilities.
- Supported branches: main
- We use dependency auditing and fuzzing; see CI for details.
