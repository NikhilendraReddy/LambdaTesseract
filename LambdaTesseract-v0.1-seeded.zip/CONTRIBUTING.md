# Contributing

1. Discuss changes via an LTP (LambdaTesseract Proposal) in `rfcs/`.
2. Write tests. Keep PRs focused.
3. Run `make precommit` to format, lint, and test.
