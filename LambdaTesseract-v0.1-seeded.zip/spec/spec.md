# LambdaTesseract Language Specification (v0.1-draft)

## 1. Lexical
Tokens, whitespace, comments, identifiers, literals.

## 2. Grammar (EBNF excerpt)
```
Program     = { Statement } ;
Statement   = Let | Def | Expr | TypeDef ;
Let         = "let" Ident [":" Type] "=" Expr ;
Def         = "def" Ident "(" [Params] ")" [":" Type] "=" Expr ;
TypeDef     = "type" Ident "=" SumType ;
Expr        = Pipeline ;
Pipeline    = Term { "->" Term } ;
Term        = Atom | Call | Lambda | Match ;
```
## 3. Static semantics
- HM type inference with ADTs and parametric polymorphism.
- Effect annotations: `IO[Read|Write]`, `Net[GET|POST]`, `Task`.
- Capability constraints enforced at function boundaries.

## 4. Dynamic semantics
- Eager evaluation with tail-call elimination.
- Structured concurrency: tasks cancel on scope exit.

## 5. Standard library surface (excerpt)
- `Option[T] = Some(T) | None`
- `Result[T, E] = Ok(T) | Err(E)`
- Collections: `List[T]`, `Map[K,V]`
- `Task[T]` with `async/await`

## 6. Conformance
- Tests in `tests/` are normative for v0.1.
