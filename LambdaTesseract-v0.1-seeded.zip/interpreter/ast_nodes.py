from dataclasses import dataclass
from typing import List, Optional, Any

@dataclass
class Program:
    statements: List[Any]

@dataclass
class Let:
    name: str
    expr: Any

@dataclass
class Def:
    name: str
    params: List[str]
    body: Any

@dataclass
class Pipeline:
    head: Any
    stages: List[Any]  # each stage is a Call or Ident

@dataclass
class Call:
    func: Any  # Ident or expression
    args: List[Any]

@dataclass
class Ident:
    name: str

@dataclass
class Number:
    value: float | int

@dataclass
class String:
    value: str

@dataclass
class BinOp:
    left: Any
    op: str
    right: Any
