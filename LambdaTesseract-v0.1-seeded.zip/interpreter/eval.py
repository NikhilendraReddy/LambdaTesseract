from .ast_nodes import Program, Let, Def, Pipeline, Call, Ident, Number, String, BinOp

class Env(dict):
    def __init__(self, parent=None):
        super().__init__()
        self.parent = parent
    def get(self, key):
        if key in self:
            return super().get(key)
        if self.parent:
            return self.parent.get(key)
        raise NameError(f'Undefined name: {key}')

def std_env():
    import math, functools, operator
    env = Env()
    # core funcs
    env['print'] = lambda x: (print(x), x)[1]
    env['upper'] = lambda s: s.upper()
    env['lower'] = lambda s: s.lower()
    env['reverse'] = lambda s: s[::-1] if isinstance(s, str) else list(reversed(s))
    env['len'] = lambda x: len(x)
    env['str'] = lambda x: str(x)
    env['int'] = lambda x: int(x)
    env['float'] = lambda x: float(x)
    env['add'] = lambda a, b: a + b
    env['sub'] = lambda a, b: a - b
    env['mul'] = lambda a, b: a * b
    env['div'] = lambda a, b: a / b
    env['map'] = lambda xs, f: [f(x) for x in xs]
    env['filter'] = lambda xs, f: [x for x in xs if f(x)]
    env['reduce'] = lambda xs, f, init: functools.reduce(f, xs, init)
    env['eq'] = lambda a, b: a == b
    env['gt'] = lambda a, b: a > b
    env['lt'] = lambda a, b: a < b
    # lambda to wrap Python callables to arity-1 if used in pipeline
    return env

def eval_program(p: Program, env=None):
    env = std_env() if env is None else env
    last = None
    for stmt in p.statements:
        last = eval_node(stmt, env)
    return last, env

def eval_node(node, env):
    if isinstance(node, Let):
        val = eval_node(node.expr, env)
        env[node.name] = val
        return val
    if isinstance(node, Def):
        # support recursion by pre-binding name
        def func_factory(params, body, closure_env):
            def fn(*args):
                local = Env(parent=closure_env)
                for name, val in zip(params, args):
                    local[name] = val
                return eval_node(body, local)
            return fn
        fn = func_factory(node.params, node.body, env)
        env[node.name] = fn
        return fn
    if isinstance(node, Pipeline):
        acc = eval_node(node.head, env)
        for stage in node.stages:
            acc = apply_stage(stage, acc, env)
        return acc
    if isinstance(node, Call):
        f = eval_node(node.func, env)
        args = [eval_node(a, env) for a in node.args]
        return f(*args)
    if isinstance(node, Ident):
        return env.get(node.name)
    if isinstance(node, Number):
        return node.value
    if isinstance(node, String):
        return node.value
    if isinstance(node, BinOp):
        l = eval_node(node.left, env)
        r = eval_node(node.right, env)
        if node.op == 'PLUS': return l + r
        if node.op == 'MINUS': return l - r
        if node.op == 'STAR': return l * r
        if node.op == 'SLASH': return l / r
        raise RuntimeError(f'Unknown op {node.op}')
    raise RuntimeError(f'Unknown node {node}')

def apply_stage(stage, acc, env):
    # stage can be Ident, Call, or any expr; if it's a Call, inject acc as first arg
    if isinstance(stage, Ident):
        f = env.get(stage.name)
        return f(acc)
    if isinstance(stage, Call):
        f = eval_node(stage.func, env)
        args = [eval_node(a, env) for a in stage.args]
        return f(acc, *args)
    # otherwise treat as function returning callable
    callee = eval_node(stage, env)
    return callee(acc)
