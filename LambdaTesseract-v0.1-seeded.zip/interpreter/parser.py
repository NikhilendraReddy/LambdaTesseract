from .lexer import tokenize
from .ast_nodes import Program, Let, Def, Pipeline, Call, Ident, Number, String, BinOp

class Parser:
    def __init__(self, code: str):
        self.tokens = list(tokenize(code))
        self.i = 0

    def peek(self):
        return self.tokens[self.i]

    def pop(self, t=None):
        tok = self.tokens[self.i]
        if t and tok.type != t:
            raise SyntaxError(f'Expected {t}, got {tok.type} at {tok.pos}')
        self.i += 1
        return tok

    def parse(self):
        stmts = []
        while self.peek().type != 'EOF':
            if self.peek().type == 'NEWLINE':
                self.pop('NEWLINE')
                continue
            stmts.append(self.statement())
            if self.peek().type == 'NEWLINE':
                self.pop('NEWLINE')
        return Program(stmts)

    def statement(self):
        if self.peek().type == 'LET':
            self.pop('LET')
            name = self.pop('IDENT').value
            self.pop('EQ')
            expr = self.expr()
            return Let(name, expr)
        if self.peek().type == 'DEF':
            self.pop('DEF')
            name = self.pop('IDENT').value
            self.pop('LPAREN')
            params = []
            if self.peek().type != 'RPAREN':
                while True:
                    params.append(self.pop('IDENT').value)
                    if self.peek().type == 'COMMA':
                        self.pop('COMMA'); continue
                    break
            self.pop('RPAREN')
            self.pop('EQ')
            body = self.expr()
            return Def(name, params, body)
        return self.expr()

    # Pratt parser for precedence
    def expr(self):
        node = self.term()
        # pipeline chains
        while self.peek().type == 'ARROW':
            self.pop('ARROW')
            stage = self.term()
            node = Pipeline(node, [stage] if not isinstance(node, Pipeline) else node.stages + [stage]) if isinstance(node, Pipeline) else Pipeline(node, [stage])
        return node

    def term(self):
        node = self.factor()
        while self.peek().type in ('PLUS','MINUS'):
            op = self.pop().type
            right = self.factor()
            node = BinOp(node, op, right)
        return node

    def factor(self):
        node = self.unary()
        while self.peek().type in ('STAR','SLASH'):
            op = self.pop().type
            right = self.unary()
            node = BinOp(node, op, right)
        return node

    def unary(self):
        tok = self.peek()
        if tok.type == 'MINUS':
            self.pop('MINUS')
            return BinOp(Number(0), 'MINUS', self.unary())
        return self.call()

    def call(self):
        node = self.primary()
        while self.peek().type == 'LPAREN':
            self.pop('LPAREN')
            args = []
            if self.peek().type != 'RPAREN':
                while True:
                    args.append(self.expr())
                    if self.peek().type == 'COMMA':
                        self.pop('COMMA'); continue
                    break
            self.pop('RPAREN')
            node = Call(node, args)
        return node

    def primary(self):
        tok = self.peek()
        if tok.type == 'NUMBER':
            self.pop('NUMBER')
            return Number(tok.value)
        if tok.type == 'STRING':
            self.pop('STRING')
            return String(tok.value)
        if tok.type == 'IDENT':
            self.pop('IDENT')
            return Ident(tok.value)
        if tok.type == 'LPAREN':
            self.pop('LPAREN')
            node = self.expr()
            self.pop('RPAREN')
            return node
        raise SyntaxError(f'Unexpected token {tok.type} at {tok.pos}')

def parse(code: str) -> Program:
    return Parser(code).parse()
