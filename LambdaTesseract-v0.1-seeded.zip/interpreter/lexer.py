import re
TOKEN_SPEC = [
    ('NUMBER',   r'\d+(?:_\d+)*(?:\.\d+)?'),
    ('STRING',   r'"([^\\"\n]|\\.)*"'),
    ('DEF',      r'def\b'),
    ('LET',      r'let\b'),
    ('ARROW',    r'->'),
    ('LPAREN',   r'\('),
    ('RPAREN',   r'\)'),
    ('COMMA',    r','),
    ('EQ',       r'='),
    ('IDENT',    r'[A-Za-z_][A-Za-z0-9_]*'),
    ('PLUS',     r'\+'),
    ('MINUS',    r'-'),
    ('STAR',     r'\*'),
    ('SLASH',    r'/'),
    ('NEWLINE',  r'\n'),
    ('SKIP',     r'[ \t]+'),
    ('MISMATCH', r'.'),
]

TOK_REGEX = re.compile('|'.join('(?P<%s>%s)' % pair for pair in TOKEN_SPEC))

class Token:
    __slots__ = ('type', 'value', 'pos')
    def __init__(self, type_, value, pos):
        self.type = type_
        self.value = value
        self.pos = pos
    def __repr__(self):
        return f'Token({self.type},{self.value!r},{self.pos})'

def tokenize(code):
    line_start = 0
    for m in TOK_REGEX.finditer(code):
        kind = m.lastgroup
        value = m.group()
        pos = m.start()
        if kind == 'NUMBER':
            if '.' in value:
                value = float(value.replace('_',''))
            else:
                value = int(value.replace('_',''))
            yield Token('NUMBER', value, pos)
        elif kind == 'STRING':
            s = value[1:-1]
            s = bytes(s, 'utf-8').decode('unicode_escape')
            yield Token('STRING', s, pos)
        elif kind == 'IDENT' or kind in ('DEF','LET','ARROW','LPAREN','RPAREN','COMMA','EQ','PLUS','MINUS','STAR','SLASH'):
            yield Token(kind, value, pos)
        elif kind == 'NEWLINE':
            yield Token('NEWLINE', '\n', pos)
        elif kind == 'SKIP':
            continue
        elif kind == 'MISMATCH':
            raise SyntaxError(f'Unexpected character {value!r} at {pos}')
    yield Token('EOF', '', len(code))
