#!/usr/bin/env python3
import sys, argparse, pathlib
from .parser import parse
from .eval import eval_program

BANNER = "LambdaTesseract (interpreter v0.1) — Founder: NIKHIL REDDY"

def main():
    ap = argparse.ArgumentParser(description=BANNER)
    ap.add_argument("file", nargs="?", help="Program file (.lt)")
    ap.add_argument("-e", "--exec", help="Execute inline code")
    args = ap.parse_args()

    if args.exec:
        code = args.exec
        val, _ = eval_program(parse(code))
        print(val)
        return

    if not args.file:
        print(BANNER)
        print("Usage: ltc.py program.lt or -e '1 -> add(2)'")
        sys.exit(0)

    path = pathlib.Path(args.file)
    code = path.read_text(encoding="utf-8")
    val, _ = eval_program(parse(code))
    if val is not None:
        print(val)

if __name__ == "__main__":
    main()
