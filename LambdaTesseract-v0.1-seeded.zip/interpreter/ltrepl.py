#!/usr/bin/env python3
import sys, readline
from .parser import parse
from .eval import eval_program

BANNER = "LambdaTesseract REPL (toy) — Ctrl+C to exit"

def run_line(src: str, env):
    prog = parse(src)
    val, env = eval_program(prog, env)
    return val, env

def main():
    print(BANNER)
    env = {}
    while True:
        try:
            line = input("lt> ")
            if not line.strip():
                continue
            val, env = run_line(line, env)
            print(repr(val))
        except (EOFError, KeyboardInterrupt):
            print("\nbye")
            sys.exit(0)
        except Exception as e:
            print("error:", e)

if __name__ == "__main__":
    main()
