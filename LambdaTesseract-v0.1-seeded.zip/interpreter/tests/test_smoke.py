from interpreter.parser import parse
from interpreter.eval import eval_program

def test_let_pipeline():
    p = parse("let x = 1 -> double")
    val, env = eval_program(p)
    assert env["x"] == "double"  # placeholder behavior
