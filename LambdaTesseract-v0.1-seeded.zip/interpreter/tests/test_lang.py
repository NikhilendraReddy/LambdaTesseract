from interpreter.parser import parse
from interpreter.eval import eval_program

def run(code):
    return eval_program(parse(code))[0]

def test_arith():
    assert run("1 + 2 * 3") == 7

def test_pipeline_call():
    assert run("1 -> add(2) -> mul(3)") == 9

def test_def_and_call():
    code = "def sq(n) = n * n\nsq(4)"
    assert run(code) == 16
