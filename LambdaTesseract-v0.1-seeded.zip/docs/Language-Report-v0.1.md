# LambdaTesseract Language Report (v0.1-draft)
**Founder & Editor**: **NIKHIL REDDY**

This report specifies the core syntax and semantics for the LambdaTesseract language.

## Design Principles
- Easy to write (concise, pipeline-oriented).
- Hard to exploit (safety by default).
- Fast to build (incremental & parallel compilation).

## Core Syntax (excerpt)
- Bindings: `let x = 1`
- Functions: `def add(a, b) = a + b`
- Pipelines: `value -> func(arg)` equivalent to `func(value, arg)`
- Strings: `"text"`; Numbers: `123`

## Semantics (excerpt)
- Eager evaluation.
- Pure functions by default; side-effects via explicit functions (`print`, `io.*` in std).
- Pipeline applies the left expression into the next function call as the first argument.

## Security (excerpt)
- Capability-based standard library for IO.
- No raw pointers in userland; safe runtime.
- Sandboxed execution target (WASM) recommended for untrusted code.
