# LTP-0000: Title

## Status
Draft

## Motivation
Why is this change needed?

## Design
Detailed proposal & semantics.

## Drawbacks & Alternatives
What are the trade-offs?

## Security considerations
Threat model, mitigations, migration.

## Backwards compatibility
Impact and plan.

## Reference implementation
Links to PRs/tests.
