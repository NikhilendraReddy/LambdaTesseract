Core library stubs. In v0.1: Option, Result, List, Map, String, IO, Task.
