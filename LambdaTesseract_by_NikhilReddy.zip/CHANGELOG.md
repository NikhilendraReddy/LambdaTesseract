# Changelog (v0.1 -> v0.1-improved)

- Parser: support ';' and ';;' comments.
- Core: added (load) special form, spawn returns Future with join().
- Stdlib: string helpers, regex-match, read-file, write-file, file-exists?.
- Improved README and added FOUNDER.md.
- Better error messages in evaluator.
