# RFC 0001 — Initial language core

Proposes the initial core forms and standard library for v0.1.
