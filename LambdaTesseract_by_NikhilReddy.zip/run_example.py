# convenience script — run an example file
import sys
from lambdatesseract.core import run_file
if len(sys.argv) < 2:
    print("Usage: python run_example.py examples/factorial.lt")
else:
    run_file(sys.argv[1])
