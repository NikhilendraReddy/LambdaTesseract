# Founder

The founder of the Lambda Tesseract programming language is **Nikhil Reddy**.
