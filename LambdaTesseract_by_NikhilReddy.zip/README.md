# Lambda Tesseract — v0.1 (improved)

**Founder:** Nikhil Reddy

A small, self-contained **toy** programming language inspired by lambda calculus and Scheme.
This repository contains an interpreter, REPL, examples, and tests.

## Highlights (new in this improved seed)
- `;` and `;;` end-of-line comments supported.
- `(load "file.lt")` special form to load and evaluate files.
- `spawn` returns a Future-like object with `.join()` to wait for result.
- Additional stdlib: string helpers, regex matching, file read/write.
- Improved error messages and better REPL behavior.

## Quick syntax
- S-expression syntax, e.g. `(define square (lambda (x) (* x x)))`
- Special forms: `define`, `lambda`, `if`, `begin`, `set!`, `quote`, `load`
- Example: factorial (in `examples/factorial.lt`)
- Start REPL:
```
python -m lambdatesseract
```

## How to push this to GitHub
(See previous README section for the standard git commands)
