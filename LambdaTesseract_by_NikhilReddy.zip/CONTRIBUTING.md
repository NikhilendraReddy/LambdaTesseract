Thanks for your interest!

- Use `pytest` for tests.
- Keep changes small and documented in `rfcs/` for language-affecting changes.
