import re
from typing import List

# Symbol class to differentiate identifiers from literal strings
class Symbol(str):
    pass

def remove_comments(s: str):
    # remove ; or ;; comments but not inside strings
    res = []
    in_str = False
    escaped = False
    i = 0
    while i < len(s):
        ch = s[i]
        if in_str:
            res.append(ch)
            if escaped:
                escaped = False
            else:
                if ch == '\\':
                    escaped = True
                elif ch == '"':
                    in_str = False
            i += 1
        else:
            if ch == '"':
                in_str = True
                res.append(ch)
                i += 1
            elif ch == ';':
                # skip until end of line
                while i < len(s) and s[i] != '\n':
                    i += 1
                # keep newline if present
                if i < len(s):
                    res.append('\n')
                    i += 1
            else:
                res.append(ch)
                i += 1
    return ''.join(res)

def tokenize(s: str):
    s = remove_comments(s)
    # tokens: "..." strings, parentheses, or barewords
    token_re = re.compile(r'"(?:\\.|[^"\\])*"|[()]|[^()\s]+', re.S)
    tokens = token_re.findall(s)
    return tokens

def atom(token: str):
    # quoted string
    if token.startswith('"') and token.endswith('"'):
        # unescape quotes inside
        inner = token[1:-1]
        return inner.replace('\\"', '"').replace('\\\\', '\\')
    # booleans
    if token == 'true':
        return True
    if token == 'false':
        return False
    # nil
    if token == 'nil':
        return []
    # numbers
    try:
        if '.' in token:
            return float(token)
        else:
            return int(token)
    except ValueError:
        return Symbol(token)

def read_from_tokens(tokens: List[str]):
    if len(tokens) == 0:
        raise SyntaxError("unexpected EOF while reading")
    token = tokens.pop(0)
    if token == '(':
        L = []
        while tokens[0] != ')':
            L.append(read_from_tokens(tokens))
            if len(tokens) == 0:
                raise SyntaxError("unexpected EOF while reading (missing ')')")
        tokens.pop(0)  # pop ')'
        return L
    elif token == ')':
        raise SyntaxError("unexpected )")
    else:
        return atom(token)

def parse(s: str):
    tokens = tokenize(s)
    if len(tokens) == 0:
        return []
    parsed = []
    while tokens:
        parsed.append(read_from_tokens(tokens))
    return parsed
