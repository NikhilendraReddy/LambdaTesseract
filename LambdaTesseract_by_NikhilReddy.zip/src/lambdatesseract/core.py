"""Core evaluator for Lambda Tesseract (v0.1) with improvements."""

from .parser import parse, Symbol
import threading, functools, operator, math, re, os
from typing import Any

# Simple lexical environment with chain
class Env(dict):
    def __init__(self, params=(), args=(), outer=None):
        super().__init__()
        # params is sequence of symbols (Symbol or str) and args are values
        for k, v in zip(params, args):
            self[k] = v
        self.outer = outer
    def find(self, var):
        if var in self:
            return self
        elif self.outer is not None:
            return self.outer.find(var)
        else:
            return None

# Procedure wrapper for user-defined functions
class Procedure:
    def __init__(self, params, body, env: Env):
        # params: list of Symbol
        self.params = params
        self.body = body if isinstance(body, list) else [body]
        self.env = env
    def __call__(self, *args):
        local = Env(self.params, args, outer=self.env)
        result = None
        for expr in self.body:
            result = eval_lt(expr, local)
        return result
    def __repr__(self):
        return f"<Procedure params={self.params}>"

# Future-like object returned by spawn
class Future:
    def __init__(self, target=None):
        self._result = None
        self._exc = None
        self._done = threading.Event()
        self._target = target

    def _runner(self):
        try:
            if self._target is None:
                self._result = None
            else:
                self._result = self._target()
        except Exception as e:
            self._exc = e
        finally:
            self._done.set()

    def join(self, timeout=None):
        self._done.wait(timeout)
        if self._exc:
            raise self._exc
        return self._result

    def done(self):
        return self._done.is_set()

    def __repr__(self):
        return f"<Future done={self.done()}>"

# helper to call either Python primitive or Procedure
def apply_proc(proc, *args):
    if isinstance(proc, Procedure):
        return proc(*args)
    elif callable(proc):
        return proc(*args)
    else:
        raise TypeError(f"not callable: {proc}")

# spawn helper (returns the Future object)
def spawn_thread(target):
    # target expected to be a Procedure or Python callable
    if isinstance(target, Procedure):
        fn = lambda: target()
    elif callable(target):
        fn = lambda: target()
    else:
        raise TypeError("spawn expects a procedure or callable")
    future = Future(target=fn)
    t = threading.Thread(target=future._runner)
    t.daemon = True
    t.start()
    return future

# Standard environment
def standard_env():
    env = Env()
    # arithmetic and math
    env.update({
        '+': lambda *a: sum(a),
        '-': lambda a, *rest: a - sum(rest) if rest else -a,
        '*': lambda *a: functools.reduce(operator.mul, a, 1),
        '/': lambda a, *rest: functools.reduce(operator.truediv, rest, a) if rest else 1.0/a,
        'pow': lambda a,b: a**b,
        'sqrt': lambda a: math.sqrt(a),
        # comparisons
        '=': lambda a,b: a == b,
        '<': lambda a,b: a < b,
        '>': lambda a,b: a > b,
        '<=': lambda a,b: a <= b,
        '>=': lambda a,b: a >= b,
        # list ops
        'list': lambda *a: list(a),
        'cons': lambda a,b: [a] + list(b) if isinstance(b, list) else [a,b],
        'car': lambda a: a[0] if a else None,
        'cdr': lambda a: a[1:] if a else [],
        # io
        'print': lambda *a: (print(*a), None)[1],
        # higher-order helpers (map/filter accept a user Procedure or builtin callable)
        'map': lambda f,l: [apply_proc(f, x) for x in l],
        'filter': lambda f,l: [x for x in l if apply_proc(f, x)],
        'reduce': lambda f, init, l: functools.reduce(lambda acc, x: apply_proc(f, acc, x), l, init),
        # concurrency
        'spawn': lambda f: spawn_thread(f),
        # booleans and nil
        'true': True,
        'false': False,
        'nil': [],
        # string helpers
        'string-length': lambda s: len(s),
        'string-append': lambda *parts: "".join(parts),
        'substring': lambda s,a,b=None: s[a:b] if b is not None else s[a:],
        # regex match: returns truthy match object or None
        'regex-match': lambda pattern, s: re.search(pattern, s),
        # file IO
        'read-file': lambda path: open(path, 'r', encoding='utf-8').read(),
        'write-file': lambda path, content: (open(path,'w',encoding='utf-8').write(content), None)[1],
        # os helpers
        'file-exists?': lambda path: os.path.exists(path),
    })
    return env

# The global top-level environment
GLOBAL_ENV = standard_env()

# Evaluator with improved error messages
def eval_lt(x, env: Env = None):
    if env is None:
        env = GLOBAL_ENV
    try:
        # symbol lookup
        if isinstance(x, Symbol):
            found = env.find(x)
            if found is None:
                raise NameError(f"unbound symbol: {x}")
            return found[x]
        # literal (number, Python string, boolean, list)
        if not isinstance(x, list):
            return x
        if len(x) == 0:
            return []
        first = x[0]
        # special forms
        if first == 'quote':
            (_, exp) = x
            return exp
        if first == 'if':
            try:
                (_, test, conseq, alt) = x
            except Exception:
                raise SyntaxError("if form requires (if test consequent alternative)")
            result = eval_lt(test, env)
            if result:
                return eval_lt(conseq, env)
            else:
                return eval_lt(alt, env)
        if first == 'define':
            # (define name expr)  or (define (fname params...) body)
            if isinstance(x[1], list):
                fname = x[1][0]
                params = x[1][1:]
                # wrap single-body as list
                if len(x) == 3:
                    body = [x[2]]
                else:
                    body = x[2:]
                proc = Procedure(params, body, env)
                env[fname] = proc
                return proc
            else:
                name = x[1]
                val = eval_lt(x[2], env)
                env[name] = val
                return val
        if first == 'lambda':
            # (lambda (params...) body...)
            params = x[1]
            # ensure body is a list of expressions; if there's a single expression wrap it
            if len(x) == 3:
                body = [x[2]]
            else:
                body = x[2:]
            return Procedure(params, body, env)
        if first == 'begin':
            val = None
            for expr in x[1:]:
                val = eval_lt(expr, env)
            return val
        if first == 'set!':
            name = x[1]
            val = eval_lt(x[2], env)
            frame = env.find(name)
            if frame is None:
                raise NameError(f"attempt to set! unknown name {name}")
            frame[name] = val
            return val
        if first == 'load':
            # (load "path")
            path = eval_lt(x[1], env)
            if not isinstance(path, str):
                raise TypeError("load expects a string path")
            if not os.path.exists(path):
                raise FileNotFoundError(f"file not found: {path}")
            with open(path, "r", encoding="utf-8") as f:
                return eval_str(f.read(), env)
        # function application
        proc = eval_lt(first, env)
        args = [eval_lt(arg, env) for arg in x[1:]]
        return apply_proc(proc, *args)
    except Exception as e:
        # include a helpful message but re-raise
        raise type(e)(f"{e} -- while evaluating: {repr(x)}") from e

# Convenience: evaluate a string containing zero or more top-level expressions.
def eval_str(s: str, env: Env = None):
    # default to GLOBAL_ENV so top-level defines persist across calls
    if env is None:
        env = GLOBAL_ENV
    parsed = parse(s)
    result = None
    for expr in parsed:
        result = eval_lt(expr, env)
    return result

# Run a script file (evaluate top-level expressions in order)
def run_file(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return eval_str(f.read())

# Simple REPL
def start_repl(prompt="λt> "):
    import sys
    print("Lambda Tesseract v0.1 — REPL. Ctrl-D or Ctrl-C to exit.")
    try:
        while True:
            try:
                s = input(prompt)
            except EOFError:
                print()
                break
            if not s.strip():
                continue
            try:
                result = eval_str(s)
                if result is not None:
                    print(repr(result))
            except Exception as e:
                print("Error:", e)
    except KeyboardInterrupt:
        print("\nBye.")
