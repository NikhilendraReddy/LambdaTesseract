import sys
from .core import start_repl, run_file

def main():
    if len(sys.argv) > 1:
        # run file(s)
        for p in sys.argv[1:]:
            try:
                run_file(p)
            except Exception as e:
                print(f"Error running {p}: {e}")
    else:
        start_repl()

if __name__ == "__main__":
    main()
