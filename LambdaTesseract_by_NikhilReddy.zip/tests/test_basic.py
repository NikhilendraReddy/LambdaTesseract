from lambdatesseract.core import eval_str
def test_arithmetic():
    assert eval_str("(+ 1 2 3)") == 6
    assert eval_str("(- 10 3)") == 7
def test_factorial():
    eval_str("""
    (define fact
      (lambda (n)
        (if (< n 2)
            1
            (* n (fact (- n 1))))))
    """ )
    assert eval_str("(fact 5)") == 120
